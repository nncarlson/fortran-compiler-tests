#!/bin/bash

set -v
ifort --version
ifort -c truchas/functions/vector_func_class.F90 truchas/functions/fptr_vector_func_type.F90

cd truchas
ifort -c functions/vector_func_class.F90 functions/fptr_vector_func_type.F90
