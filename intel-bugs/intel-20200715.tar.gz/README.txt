INTERNAL COMPILER ERROR

This example reproduces an ICE in the 19.1.1 compiler. This is a regression against
19.1.0 and all earlier versions.

The script compile.sh compiles two small source files located in the subdirectory truchas/functions.
This fails with an ICE on the second file. But if the current working directory is changed to truchas
and the same two files (now in the subdirectory functions) are compiled this succeeds as expected.

Here's the output of the script:

./compile.sh

ifort --version
ifort (IFORT) 19.1.1.217 20200306
Copyright (C) 1985-2020 Intel Corporation.  All rights reserved.

ifort -c truchas/functions/vector_func_class.F90 truchas/functions/fptr_vector_func_type.F90
/tmp/ifortp2HhX1.i90: catastrophic error: **Internal compiler error: segmentation violation signal raised** Please report this error along with the circumstances in which it occurred in a Software Problem Report.  Note: File and line given may not be explicit cause of this error.
compilation aborted for truchas/functions/fptr_vector_func_type.F90 (code 1)

cd truchas
ifort -c functions/vector_func_class.F90 functions/fptr_vector_func_type.F90
